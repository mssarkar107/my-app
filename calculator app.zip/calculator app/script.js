let unlockCode = ''; 
const lockedPhotos = []; 

function appendToDisplay(value) {
    const display = document.getElementById('display');
    display.value += value;
}

function clearDisplay() {
    const display = document.getElementById('display');
    display.value = '';
}

function deleteLast() {
    const display = document.getElementById('display');
    display.value = display.value.slice(0, -1);
}

function setCode() {
    const display = document.getElementById('display');
    if (display.value.length === 0) {
        alert("Please enter a code.");
        return;
    }
    
    unlockCode = display.value;
    alert("Code set successfully! Please remember your code.");
    
    document.getElementById('setCodeButton').style.display = 'none';
    document.getElementById('calculateButton').style.display = 'block';

    clearDisplay();
}

function calculate() {
    const display = document.getElementById('display');
    const enteredValue = display.value;

    // If a code has not been set yet, perform normal calculations
    if (!unlockCode) {
        try {
            const result = eval(enteredValue); // Evaluate the expression
            display.value = result; // Show result in the display
        } catch (error) {
            alert('Invalid calculation!'); // Show alert for invalid calculations
            clearDisplay();
        }
        return; // Exit the function after normal calculation
    }

    // If a code has been set, check for the unlock code
    if (enteredValue === unlockCode) {
        showGallery();
    } else {
        // Check if the entered value is a valid calculation
        try {
            const result = eval(enteredValue); // Evaluate the expression
            display.value = result; // Show result in the display
        } catch (error) {
            alert('Invalid code or calculation!'); // Alert for invalid code or calculation
            clearDisplay();
        }
    }
}

function uploadPhoto() {
    const photoInput = document.getElementById('photoInput');
    photoInput.click();
}

function displayPhotos(input) {
    const photoDisplay = document.getElementById('photoDisplay');
    const files = input.files;

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const reader = new FileReader();
        reader.onload = function (e) {
            const img = document.createElement('img');
            img.src = e.target.result;
            lockedPhotos.push(img.src); 
            img.style.width = '100px'; 
            img.style.margin = '10px'; 
            img.onclick = function() {
                openModal(img.src); // Open modal on click
            };

            const removeButton = document.createElement('span');
            removeButton.innerText = 'Remove';
            removeButton.className = 'remove-photo';
            removeButton.onclick = function() {
                removePhoto(img.src);
            };
            
            const container = document.createElement('div');
            container.className = 'photo-container';
            container.appendChild(img);
            container.appendChild(removeButton);
            photoDisplay.appendChild(container);
        };
        reader.readAsDataURL(file);
    }
}

function openModal(src) {
    const modal = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    modal.style.display = "block"; // Show the modal
    modalImage.src = src; // Set the clicked image as the modal image
}

function closeModal() {
    const modal = document.getElementById('imageModal');
    modal.style.display = "none"; // Hide the modal
}

function removePhoto(src) {
    const photoDisplay = document.getElementById('photoDisplay');
    const photos = document.querySelectorAll('#photoDisplay img');

    photos.forEach(photo => {
        if (photo.src === src) {
            photoDisplay.removeChild(photo.parentNode); 
            lockedPhotos.splice(lockedPhotos.indexOf(src), 1);
        }
    });
}

function hideGallery() {
    document.getElementById('calculator').style.display = 'block';
    document.getElementById('hiddenGallery').style.display = 'none';
}

function showGallery() {
    document.getElementById('calculator').style.display = 'none';
    document.getElementById('hiddenGallery').style.display = 'block';

    const photoDisplay = document.getElementById('photoDisplay');
    photoDisplay.innerHTML = ''; 

    lockedPhotos.forEach(src => {
        const img = document.createElement('img');
        img.src = src;
        img.style.width = '100px'; 
        img.style.margin = '10px'; 

        img.onclick = function() {
            openModal(src);
        };

        const removeButton = document.createElement('span');
        removeButton.innerText = 'Remove';
        removeButton.className = 'remove-photo';
        removeButton.onclick = function() {
            removePhoto(src);
        };

        const container = document.createElement('div');
        container.className = 'photo-container';
        container.appendChild(img);
        container.appendChild(removeButton);
        photoDisplay.appendChild(container);
    });
}
